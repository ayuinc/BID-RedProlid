/*
 * Transposh v0.9.5.1
 * http://transposh.org/
 *
 * Copyright 2014, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Sat, 25 Jan 2014 01:19:04 +0200
 */
t_jp.l={"Close without saving?":"Kaydetmeden \u00e7\u0131k\u0131\u015f yap?","You have made a change to the translation. Are you sure you want to discard it?":"\u00c7eviride de\u011fi\u015flikler yapt\u0131n\u0131z. Kaydetmeden \u00e7\u0131k\u0131\u015f yapmak istedi\u011finizden emin misiniz?",History:"Ge\u00e7mi\u015f","Loading...":"Y\u00fckleniyor...",Translated:"\u00c7evirildi",By:"\u00c7eviren:",At:"\u00c7evirildi\u011fi Sistem:",google:"google",bing:"bing",apertium:"apertium","manual translation":"manuel \u00e7eviri",
"bing suggest":"bing tavsiyesi","google suggest":"google tavsiyesi","apertium suggest":"apertium tavsiyesi","Edit Translation":"\u00c7eviriyi D\u00fczenle","Original text":"Orjinal yaz\u0131","read alternate translations":"alternatif \u00e7evirileri oku ","previous translation":"ge\u00e7mi\u015f \u00e7eviri","find on page":"sayfada aroma yap","next translation":"gelecek \u00e7eviri","Translate to":"\u015eu dile \u00e7evir","view translation log":"\u00e7eviri log verilerini g\u00f6r\u00fcnt\u00fcle",
"virtual keyboard":"sanal klavye","approve translation":"\u00e7eviriyi kabul et","delete":"sil",Discard:"\u0130ptal et",Cancel:"Vazge\u00e7"};
