/*
 * Transposh v0.9.5.1
 * http://transposh.org/
 *
 * Copyright 2014, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Sat, 25 Jan 2014 01:19:04 +0200
 */
t_jp.l={"Close without saving?":"Chiudere senza salvare?","You have made a change to the translation. Are you sure you want to discard it?":"&Egrave; stata fatta una modifica alla traduzione. Si &egrave; sicuri di volerla scartare?",History:"Storia","Loading...":"Caricamento...",Translated:"Tradotto",By:"Da",At:"A",google:"google",bing:"bing",apertium:"apertium","manual translation":"traduzione manuale","bing suggest":"bing suggerisce","google suggest":"google suggerisce","apertium suggest":"apertium suggerisce",
"Edit Translation":"Modifica Traduzione","Original text":"Testo Originale","read alternate translations":"leggi le traduzioni alternative","previous translation":"traduzione precedente","find on page":"trova nella pagina","next translation":"prossima traduzione","Translate to":"Tradotto in","view translation log":"guarda il log delle traduzioni","virtual keyboard":"tastiera virtuale","approve translation":"approva traduzione","delete":"cancella",Discard:"Scarta",Cancel:"Cancella"};
